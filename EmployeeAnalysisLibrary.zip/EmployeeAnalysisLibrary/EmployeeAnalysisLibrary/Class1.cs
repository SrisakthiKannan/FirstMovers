﻿using System;
using System.Collections.Generic;
using System.Activities;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data;
using Microsoft.Azure.CognitiveServices.Language.TextAnalytics;
using System.Reflection;

namespace EmployeeAnalysisLibrary
{
	public class Class1 : CodeActivity
	{
		string connectionString = "Server=tcp:dbavinash.database.windows.net,1433;Initial Catalog=Demo;Persist Security Info=False;User ID=serverlogin;Password=Admin@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
		private string textKey = "8bedb160a2714db5bfa911de7c08a2ce";
		private string endpoint = @"https://eastus.api.cognitive.microsoft.com/";

		//[Category("Input")]
		//[RequiredArgument]
		//public InArgument<string> ServerName { get; set; }

		//[Category("Input")]
		//[RequiredArgument]
		//public InArgument<string> DatabaseName { get; set; }

		//[Category("Input")]
		//[RequiredArgument]
		//public InArgument<string> UserName { get; set; }

		//[Category("Input")]
		//[RequiredArgument]
		//public InArgument<string> UserPassword { get; set; }

		//[Category("Input")]
		//[RequiredArgument]
		//public InArgument<string> Key { get; set; }

		//[Category("Input")]
		//[RequiredArgument]
		//public InArgument<string> Endpoint { get; set; }

		[Category("Output")]
		public OutArgument<DataTable> PredictedResult { get; set; }

		//public void GetMappingData()
		//{
		//	DataTable dt = new DataTable();
		//	string connectionString = "Server=tcp:dbavinash.database.windows.net,1433;Initial Catalog=Demo;Persist Security Info=False;User ID=serverlogin;Password=Admin@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
		//	//SqlConnection connection = new SqlConnection(sConnB.ConnectionString);
		//	SqlConnection connection = new SqlConnection(connectionString);
		//	SqlCommand command = new SqlCommand("GetEmployeeScore", connection);
		//	command.CommandType = System.Data.CommandType.StoredProcedure;
		//	connection.Open();

		//	using (SqlDataAdapter sda = new SqlDataAdapter(command))
		//	{
		//		sda.Fill(dt);
		//	}
		//	List<Employee> empObjectList = GetEmployeeMapping(dt);
		//	dt = DoSentimentAnalysis(empObjectList);
		//}
		protected override void Execute(CodeActivityContext context)
		{
			DataTable dt = new DataTable();
			
			SqlConnection connection = new SqlConnection(connectionString);

			SqlCommand command = new SqlCommand("GetEmployeeScore", connection);
			command.CommandType = System.Data.CommandType.StoredProcedure;
			connection.Open();

			using (SqlDataAdapter sda = new SqlDataAdapter(command))
			{
				sda.Fill(dt);
			}
			List<Employee> empObjectList = GetEmployeeMapping(dt);
			dt = DoSentimentAnalysis(empObjectList);
			PredictedResult.Set(context, dt);
		}

		private List<Employee> GetEmployeeMapping(DataTable dt)
		{
			List<Employee> empObjectList = new List<Employee>();

			Employee empObject = null;
			foreach (DataRow dr in dt.Rows)
			{
				empObject = new Employee();
				empObject.EmployeeId = dr["EmployeeId"].ToString();
				empObject.Location = dr["Location"].ToString();
				empObject.Vertical = dr["Vertical"].ToString();
				empObject.Score = Convert.ToInt32(dr["Score"]);
				empObject.TextToPredict = dr["TextToPredict"].ToString();
				empObject.SurveyDate = Convert.ToDateTime(dr["SurveyDate"]);
				empObjectList.Add(empObject);
			}

			return empObjectList;
		}

		private DataTable DoSentimentAnalysis(List<Employee> empObjectList)
		{
			var credentials = new ApiKeyServiceClientCredentials(textKey);
			TextAnalyticsClient client = new TextAnalyticsClient(credentials)
			{
				Endpoint = endpoint
			};
			foreach (Employee emp in empObjectList)
			{
				var result = client.Sentiment(emp.TextToPredict, "en");
				int textAnalysisScore = emp.Score + Convert.ToInt32(result.Score * 100);

				if (textAnalysisScore >= 0 && textAnalysisScore <= 240)
				{
					emp.SatisfactionFactor = "Low";
				}
				else if (textAnalysisScore > 240 && textAnalysisScore <= 360)
				{
					emp.SatisfactionFactor = "May be";
				}
				else
				{
					emp.SatisfactionFactor = "High";
				}

				emp.Score = textAnalysisScore;
			}

			return objToDataTable(empObjectList);

		}
		private DataTable objToDataTable(List<Employee> empObjectList)
		{
			DataTable dt = new DataTable();
			dt.TableName = "SatisfactionTable";
			Employee employeeObject = new Employee();
			foreach (PropertyInfo property in empObjectList[0].GetType().GetProperties())
			{
				if (property.Name != "TextToPredict" && property.Name != "Score")
				{
					dt.Columns.Add(new DataColumn(property.Name, property.PropertyType));
				}
			}

			foreach (var emp in empObjectList)
			{
				DataRow newRow = dt.NewRow();
				foreach (PropertyInfo property in emp.GetType().GetProperties())
				{
					if (property.Name != "TextToPredict" && property.Name != "Score")
					{
						newRow[property.Name] = emp.GetType().GetProperty(property.Name).GetValue(emp, null);
					}
				}
				dt.Rows.Add(newRow);
			}
			return dt;
		}
	}
}
