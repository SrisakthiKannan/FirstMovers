﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using EmployeeWebApp.Objects;

namespace EmployeeWebApp
{
    public partial class _Default : Page
    {
        string connectionString = "Server=tcp:dbavinash.database.windows.net,1433;Initial Catalog=Demo;Persist Security Info=False;User ID=serverlogin;Password=Admin@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        protected void Page_Load(object sender, EventArgs e)
        {
            GetQuestions();
        }       
       
        public List<Questions> GetQuestions()
        {
            List<Questions> result = new List<Questions>();

            //string quest1 = String.Format("select Description from Questionnaire where QuestionID=1");
            string quest1 = String.Format("select * from Questionnaire");

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlCommand command = new SqlCommand(quest1, connection);

            SqlDataReader dataReader = command.ExecuteReader();
            Questions quest = null;

            if (dataReader.HasRows)
            {
                while (dataReader.Read())
                {
                    quest = new Questions();
                    quest.QuestionID = Convert.ToInt32(dataReader["QuestionID"]);
                    //article.PublishDate = Convert.ToDateTime(dataReader["PublishDate"]);
                    quest.Description = dataReader["Description"].ToString();
					if (quest.QuestionID == 1)
					{
						lblQuestion1.Text = quest.Description;
					}
					if (quest.QuestionID == 2)
					{
						lblQuestion2.Text = quest.Description;
					}
					if (quest.QuestionID == 3)
					{
						lblQuestion3.Text = quest.Description;
					}
					if (quest.QuestionID == 4)
					{
						lblQuestion4.Text = quest.Description;
					}
					if (quest.QuestionID == 5)
					{
						lblQuestion5.Text = quest.Description;
					}
					if (quest.QuestionID == 6)
					{
						lblQuestion6.Text = quest.Description;
					}

					result.Add(quest);
                }
            }
            

            return result;

        }

        protected void Button1_Click(Object sender, EventArgs e)
        {
            List<EmpQuesMapping> empQuesMapList = new List<EmpQuesMapping>();
            EmpQuesMapping empQuesMap = null;
            string employeeId = EmployeeId.Text;
            DateTime surveyDate = DateTime.Today;
            Employee employeeObject = new Employee();
            employeeObject.EmployeeId = employeeId;
            employeeObject.Location = locationTxt.Text;
            employeeObject.Vertical = verticalDropDown.SelectedValue.ToString();

            //Question1
            empQuesMap = new EmpQuesMapping();

            empQuesMap.EmployeeId = employeeId;
            empQuesMap.QuestionId = 1;
            empQuesMap.Score = Convert.ToInt32(RadioButtonList1.SelectedValue);
            empQuesMap.SurveyDate = surveyDate;
            empQuesMap.Question6Input = string.Empty;
            empQuesMapList.Add(empQuesMap);

            //Question2
            empQuesMap = new EmpQuesMapping();

            empQuesMap.EmployeeId = employeeId;
            empQuesMap.QuestionId = 2;
            empQuesMap.Score = Convert.ToInt32(RadioButtonList2.SelectedValue);
            empQuesMap.SurveyDate = surveyDate;
            empQuesMap.Question6Input = string.Empty;
            empQuesMapList.Add(empQuesMap);

            //Question3
            empQuesMap = new EmpQuesMapping();

            empQuesMap.EmployeeId = employeeId;
            empQuesMap.QuestionId = 3;
            empQuesMap.Score = Convert.ToInt32(DropDownList2.SelectedValue);
            empQuesMap.SurveyDate = surveyDate;
            empQuesMap.Question6Input = string.Empty;
            empQuesMapList.Add(empQuesMap);

            //Question4
            empQuesMap = new EmpQuesMapping();

            empQuesMap.EmployeeId = employeeId;
            empQuesMap.QuestionId = 4;
            empQuesMap.Score = Convert.ToInt32(RadioButtonList3.SelectedValue);
            empQuesMap.SurveyDate = surveyDate;
            empQuesMap.Question6Input = string.Empty;
            empQuesMapList.Add(empQuesMap);

            //Question5
            empQuesMap = new EmpQuesMapping();

            empQuesMap.EmployeeId = employeeId;
            empQuesMap.QuestionId = 5;
            empQuesMap.Score = Convert.ToInt32(RadioButtonList4.SelectedValue);
            empQuesMap.SurveyDate = surveyDate;
            empQuesMap.Question6Input = string.Empty;
            empQuesMapList.Add(empQuesMap);

            //Question6
            empQuesMap = new EmpQuesMapping();

            empQuesMap.EmployeeId = employeeId;
            empQuesMap.QuestionId = 6;
            empQuesMap.Score = 0;
            empQuesMap.SurveyDate = surveyDate;
            empQuesMap.Question6Input = ques6Txt.Text;
            empQuesMapList.Add(empQuesMap);

            SaveEmployee(employeeObject);
            SaveEmpMappings(empQuesMapList);

            Clearform();

        }

        private void SaveEmployee(Employee employeeObject)
        {

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = new SqlCommand("INSERT INTO EmployeeInfo(EmployeeId, Location, Vertical) VALUES('" + employeeObject.EmployeeId + "', '" + employeeObject.Location + "', '" + employeeObject.Vertical + "')", connection);
            command.ExecuteNonQuery();

        }
        private void SaveEmpMappings(List<EmpQuesMapping> empQuesMappingList)
        {
            string sqlIns = "INSERT INTO EmpQuesMapping (EmployeeId,QuestionId,Score,Question6Input, SurveyDate) VALUES (@EmployeeId,@QuestionId, @Score,@Question6Input,@SurveyDate)";

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand cmdIns = new SqlCommand(sqlIns, connection);
            for (int i = 0; i < empQuesMappingList.Count; i++)
            {
                cmdIns.Parameters.Clear();
                cmdIns.Parameters.AddWithValue("@EmployeeId", empQuesMappingList[i].EmployeeId);
                cmdIns.Parameters.AddWithValue("@QuestionId", empQuesMappingList[i].QuestionId);
                cmdIns.Parameters.AddWithValue("@Score", empQuesMappingList[i].Score);
                cmdIns.Parameters.AddWithValue("@Question6Input", empQuesMappingList[i].Question6Input);
                cmdIns.Parameters.AddWithValue("@SurveyDate", empQuesMappingList[i].SurveyDate);
                cmdIns.ExecuteNonQuery();
            }
        }
        private void Clearform( )
        {
            EmployeeId.Text = string.Empty;
            locationTxt.Text = string.Empty;
            verticalDropDown.ClearSelection();
            ques6Txt.Text = string.Empty;
            RadioButtonList1.ClearSelection();
            RadioButtonList2.ClearSelection();
            RadioButtonList3.ClearSelection();
            RadioButtonList4.ClearSelection();
            DropDownList2.ClearSelection();
        }
    }
}