﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeWebApp.Objects
{
    public class Employee
    {
        public string EmployeeId { get; set; }
        public string Location { get; set; }
        public string Vertical { get; set; }
    }
}