﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeWebApp.Objects
{
    public class EmpQuesMapping
    {
        public string EmployeeId { get; set; }
        public int QuestionId { get; set; }
        public int Score { get; set; }

        public string Question6Input { get; set; }

        public DateTime SurveyDate { get; set; }
    }
}